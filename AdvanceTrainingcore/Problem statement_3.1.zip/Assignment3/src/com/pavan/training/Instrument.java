package com.pavan.training;

public abstract class Instrument {
	public abstract void play();
}
