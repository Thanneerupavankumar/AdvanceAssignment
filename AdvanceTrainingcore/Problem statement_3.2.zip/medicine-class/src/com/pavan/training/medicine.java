package com.pavan.training;

public class medicine{
    
    public void displayLabel()
    
    {
        System.out.println("Company : Apollo");
        System.out.println("Address : Hyderabad");
        
        }
        
        }
        
        class Tablet extends medicine{
	 
public void displayLabel()

{
    System.out.println("store is a good place");
    
    }
    }
    class Syrup extends medicine{
        public void displayLabel()
        {
            System.out.println("Consumption as directed by thephysician");
            }
            }
            class Ointment extends medicine{
                public void displayLabel(){
                    System.out.println("for external use only");
       }
 }